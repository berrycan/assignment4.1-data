
#Load data and packages ----

# load the packages
library(xlsx)
library(dplyr)
library(tidyr)
library(rstatix)
library(psych)



#load data
df<-read.xlsx("data.xlsx", sheetIndex = 1)
df[df == 'NA'] <- NA
df2<-df%>%
  select(-reward)%>%
  mutate_each(funs(as.numeric(.)))
df2$reward<-as.factor(df$reward)

df<-df2

#correlations of expressivity score across contexts----
cor.test(df$aff_expressivity_score,df$con_expressivity_score)
cor.test(df$neu_expressivity_score,df$con_expressivity_score)
cor.test(df$aff_expressivity_score,df$neu_expressivity_score)

#anovas of expressivity measures across contexts----
#####DIVERSITY SCORE----
#Convert data from wide to long format
diversity_contexts<- df%>%
  dplyr::select(ID,neu_diversity_score,aff_diversity_score,con_diversity_score)%>%
  gather(key='context',value='diversity_score',neu_diversity_score,aff_diversity_score,con_diversity_score)


#initiate variables for repeated measures anova
diversity_score<-diversity_contexts$diversity_score
diversity_contexts$ID<-as.factor(diversity_contexts$ID)
diversity_contexts$context<-as.factor(diversity_contexts$context)

#get summary stats by context
sum<- diversity_contexts %>%
  group_by(context) %>%
  summarise(n=n(),
            mean_diversity=mean(diversity_score, na.rm=TRUE), 
            sd_diversity=sd(diversity_score, na.rm=TRUE),
            se_diversity=sd_diversity/sqrt(n),na.rm=TRUE)
sum


#BOXPLOT to identify outliers.
boxplot(diversity_score~context,data=diversity_contexts, main="diversity_score across conditions",
        xlab="Context", ylab="diversity_score")
#check for outliers:
outlier<-diversity_contexts %>%
  group_by(context) %>%
  identify_outliers(diversity_score)
data.frame(outlier)
###4 outliers - 1 extreme outlier


#now do ANOVA
diversity_score_anova<-aov(diversity_score~context+Error(ID/context),diversity_contexts)
summary(diversity_score_anova) 

#now removing the outliers and re-doing ANOVA
diversity_contexts_minus_outlier<-diversity_contexts%>%
  filter(diversity_score>=1.51109)
diversity_score_anova2<-aov(diversity_score~context+Error(ID/context),diversity_contexts_minus_outlier)
summary(diversity_score_anova2) 


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = diversity_contexts, dv = diversity_score, wid = ID,
  within = context)
res.aov 

#now with outliers removed
res.aov <- anova_test(
  data = diversity_contexts_minus_outlier, dv = diversity_score, wid = ID,
  within = context)
res.aov 



#####RATE----
rate_contexts<- df%>%
  dplyr::select(ID,neu_rate,aff_rate,con_rate)%>%
  gather(key='context',value='rate',neu_rate,aff_rate,con_rate)

#check normality - q plots for N=50+. Shapiro-wilk otherwise.


#initiate variables for repeated measures anova
rate<-rate_contexts$rate 
rate_contexts$ID<-as.factor(rate_contexts$ID)
rate_contexts$context<-as.factor(rate_contexts$context)

#get summary stats by context
sum<- rate_contexts %>%
  group_by(context) %>%
  summarise(n=n(),
            mean_rate=mean(rate, na.rm=TRUE), 
            sd_rate=sd(rate, na.rm=TRUE),
            se_rate=sd_rate/sqrt(n),na.rm=TRUE)
sum



#BOXPLOT to identify outliers.
boxplot(rate~context,data=rate_contexts, main="rate across conditions",
        xlab="Context", ylab="rate")
#check for outliers:
outlier<-rate_contexts %>%
  group_by(context) %>%
  identify_outliers(rate)
data.frame(outlier)


#now do ANOVA
rate_anova<-aov(rate~context+Error(ID/context),rate_contexts)
summary(rate_anova) 

#now removing outliers and re-doing ANOVA
rate_contexts_minus_outlier<-rate_contexts%>%
  filter(rate<=156)
rate_anova2<-aov(rate~context+Error(ID/context),rate_contexts_minus_outlier)
summary(rate_anova2) 


#Using anova_test to get Mauchley's test of sphericity

res.aov <- anova_test(
  data = rate_contexts, dv = rate, wid = ID,
  within = context)
res.aov #Machly's test is significant, indicating a violation of sphericity. 



#without outliers
res.aov <- anova_test(
  data = rate_contexts_minus_outlier, dv = rate, wid = ID,
  within = context)
res.aov #Machly's test is significant, indicating a violation of sphericity. 

#for post-hoc tests
#With repeated measures, you run adjusted paired t-tests using Bonferroni correction
pwc<-pairwise.t.test(rate,rate_contexts$context,
                     paired=TRUE,p.adjust.method="bonferroni")
pwc

######DURATION-----
duration_contexts <- df %>%
  dplyr::select(ID, neu_duration, aff_duration, con_duration) %>%
  gather(key = 'context',
         value = 'duration',
         neu_duration,
         aff_duration,
         con_duration)


#initiate variables for repeated measures anova
duration<-duration_contexts$duration 
duration_contexts$ID<-as.factor(duration_contexts$ID)
duration_contexts$context<-as.factor(duration_contexts$context)
#duration_contexts$context<-relevel(duration_contexts$context,'neu_duration_percentage_duration')
#get summary stats by context
sum<- duration_contexts %>%
  group_by(context) %>%
  summarise(n=n(),
            mean_duration=mean(duration, na.rm=TRUE), 
            sd_duration=sd(duration, na.rm=TRUE),
            se_duration=sd_duration/sqrt(n),na.rm=TRUE)
sum



#BOXPLOT to identify outliers.
boxplot(duration~context,data=duration_contexts, main="duration across conditions",
        xlab="Context", ylab="duration")
#check for outliers:
outlier<-duration_contexts %>%
  group_by(context) %>%
  identify_outliers(duration)
data.frame(outlier)
###no outliers


#now do ANOVA
duration_anova<-aov(duration~context+Error(ID/context),duration_contexts)
summary(duration_anova) 

#Using anova_test to get Mauchley's test of sphericity

res.aov <- anova_test(
  data = duration_contexts, dv = duration, wid = ID,
  within = context)
res.aov 


######AU Repertoire-----
rep_contexts <- df %>%
  dplyr::select(ID, neu_rep, aff_rep, con_rep) %>%
  gather(key = 'context',
         value = 'rep',
         neu_rep,
         aff_rep,
         con_rep)

#initiate variables for repeated measures anova
rep<-rep_contexts$rep 
rep_contexts$ID<-as.factor(rep_contexts$ID)
rep_contexts$context<-as.factor(rep_contexts$context)

#get summary stats by context
sum<- rep_contexts %>%
  group_by(context) %>%
  summarise(n=n(),
            mean_rep=mean(rep, na.rm=TRUE), 
            sd_rep=sd(rep, na.rm=TRUE),
            se_rep=sd_rep/sqrt(n),na.rm=TRUE)
sum

#BOXPLOT to identify outliers.
boxplot(rep~context,data=rep_contexts, main="rep across conditions",
        xlab="Context", ylab="rep")
#check for outliers:
outlier<-rep_contexts %>%
  group_by(context) %>%
  identify_outliers(rep)
data.frame(outlier)
###2 outliers


#now do ANOVA
rep_anova<-aov(rep~context+Error(ID/context),rep_contexts)
summary(rep_anova) 

##now removing outliers and re-doing ANOVA
rep_contexts_minus_outlier<-rep_contexts%>%
  filter(rep<=14)%>%
  filter(rep>=2)
rep_anova2<-aov(rep~context+Error(ID/context),rep_contexts_minus_outlier)
summary(rep_anova2) 


#Using anova_test to get Mauchley's test of sphericity

res.aov <- anova_test(
  data = rep_contexts, dv = rep, wid = ID,
  within = context)
res.aov 

#now without outliers

res.aov <- anova_test(
  data = rep_contexts_minus_outlier, dv = rep, wid = ID,
  within = context)
res.aov 


######Corrected AU Repertoire-----
unique_contexts <- df %>%
  dplyr::select(ID, neu_cor_rep, aff_cor_rep, con_cor_rep) %>%
  gather(key = 'context',
         value = 'unique',
         neu_cor_rep, aff_cor_rep, con_cor_rep)


#initiate variables for uniqueeated measures anova
unique<-unique_contexts$unique 
unique_contexts$ID<-as.factor(unique_contexts$ID)
unique_contexts$context<-as.factor(unique_contexts$context)

#get summary stats by context
sum<- unique_contexts %>%
  group_by(context) %>%
  summarise(n=n(),
            mean_unique=mean(unique, na.rm=TRUE), 
            sd_unique=sd(unique, na.rm=TRUE),
            se_unique=sd_unique/sqrt(n),na.rm=TRUE)
sum



#BOXPLOT to identify outliers.
boxplot(unique~context,data=unique_contexts, main="unique across conditions",
        xlab="Context", ylab="unique")
#check for outliers:
outlier<-unique_contexts %>%
  group_by(context) %>%
  identify_outliers(unique)
data.frame(outlier)


#now do ANOVA
unique_anova<-aov(unique~context+Error(ID/context),unique_contexts)
summary(unique_anova)

##now removing outliers and re-doing ANOVA
unique_contexts_minus_outlier<-unique_contexts%>%
  filter(unique<=13,
         unique>=3)
unique_anova2<-aov(unique~context+Error(ID/context),unique_contexts_minus_outlier)
summary(unique_anova2) 


#Using anova_test to get Mauchley's test of sphericity

res.aov <- anova_test(
  data = unique_contexts, dv = unique, wid = ID,
  within = context)
res.aov 



######Combination Repertoire-----
combo_contexts <- df %>%
  dplyr::select(ID, neu_combo, aff_combo, con_combo) %>%
  gather(key = 'context',
         value = 'combo',
         neu_combo, aff_combo, con_combo)


#initiate variables for comboeated measures anova
combo<-combo_contexts$combo 
combo_contexts$ID<-as.factor(combo_contexts$ID)
combo_contexts$context<-as.factor(combo_contexts$context)

#get summary stats by context
sum<- combo_contexts %>%
  group_by(context) %>%
  summarise(n=n(),
            mean_combo=mean(combo, na.rm=TRUE), 
            sd_combo=sd(combo, na.rm=TRUE),
            se_combo=sd_combo/sqrt(n),na.rm=TRUE)
sum



#BOXPLOT to identify outliers.
boxplot(combo~context,data=combo_contexts, main="combo across conditions",
        xlab="Context", ylab="combo")
#check for outliers:
outlier<-combo_contexts %>%
  group_by(context) %>%
  identify_outliers(combo)
data.frame(outlier)


#now do ANOVA
combo_anova<-aov(combo~context+Error(ID/context),combo_contexts)
summary(combo_anova) #look at the ID:context part. It's not significant

##now removing outliers and re-doing ANOVA
combo_contexts_minus_outlier<-combo_contexts%>%
  filter(combo<=33)
combo_anova2<-aov(combo~context+Error(ID/context),combo_contexts_minus_outlier)
summary(combo_anova2) 


#Using anova_test to get Mauchley's test of sphericity

res.aov <- anova_test(
  data = combo_contexts, dv = combo, wid = ID,
  within = context)
res.aov 


#now without outliers
res.aov <- anova_test(
  data = combo_contexts_minus_outlier, dv = combo, wid = ID,
  within = context)
res.aov 




#emotional expressivity across contexts ------------------------------------------------

######joy----
#Convert data from wide to long format
joy_contexts<- df%>%
  select(ID,neu_percentage_joy,con_percentage_joy,aff_percentage_joy)%>%
  filter(neu_percentage_joy!="NA",con_percentage_joy!="NA",aff_percentage_joy!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='joy',neu_percentage_joy,aff_percentage_joy,con_percentage_joy)

#initiate variables for repeated measures anova
joy<-joy_contexts$joy 
joy_contexts$ID<-as.factor(joy_contexts$ID)
joy_contexts$context<-as.factor(joy_contexts$context)


#get summary stats by context
sum<- joy_contexts %>%
  group_by(context) %>%
  summarise(mean_joy=mean(joy, na.rm=TRUE), sd_joy=sd(joy, na.rm=TRUE))
sum

#now do ANOVA
joy_anova<-aov(joy~context+Error(ID/context),joy_contexts)
summary(joy_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = joy_contexts, dv = joy, wid = ID,
  within = context)
res.aov 



######surprise----
#Convert data from wide to long format
surprise_contexts<- df%>%
  select(ID,neu_percentage_surprise,con_percentage_surprise,aff_percentage_surprise)%>%
  filter(neu_percentage_surprise!="NA",con_percentage_surprise!="NA",aff_percentage_surprise!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='surprise',neu_percentage_surprise,aff_percentage_surprise,con_percentage_surprise)

#initiate variables for repeated measures anova
surprise<-surprise_contexts$surprise 
surprise_contexts$ID<-as.factor(surprise_contexts$ID)
surprise_contexts$context<-as.factor(surprise_contexts$context)


#get summary stats by context
sum<- surprise_contexts %>%
  group_by(context) %>%
  summarise(mean_surprise=mean(surprise, na.rm=TRUE), sd_surprise=sd(surprise, na.rm=TRUE))
sum

#now do ANOVA
surprise_anova<-aov(surprise~context+Error(ID/context),surprise_contexts)
summary(surprise_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = surprise_contexts, dv = surprise, wid = ID,
  within = context)
res.aov 



######anger----
#Convert data from wide to long format
anger_contexts<- df%>%
  select(ID,neu_percentage_anger,con_percentage_anger,aff_percentage_anger)%>%
  filter(neu_percentage_anger!="NA",con_percentage_anger!="NA",aff_percentage_anger!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='anger',neu_percentage_anger,aff_percentage_anger,con_percentage_anger)

#initiate variables for repeated measures anova
anger<-anger_contexts$anger 
anger_contexts$ID<-as.factor(anger_contexts$ID)
anger_contexts$context<-as.factor(anger_contexts$context)


#get summary stats by context
sum<- anger_contexts %>%
  group_by(context) %>%
  summarise(mean_anger=mean(anger, na.rm=TRUE), sd_anger=sd(anger, na.rm=TRUE))
sum

#now do ANOVA
anger_anova<-aov(anger~context+Error(ID/context),anger_contexts)
summary(anger_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = anger_contexts, dv = anger, wid = ID,
  within = context)
res.aov 



######contempt----
#Convert data from wide to long format
contempt_contexts<- df%>%
  select(ID,neu_percentage_contempt,con_percentage_contempt,aff_percentage_contempt)%>%
  filter(neu_percentage_contempt!="NA",con_percentage_contempt!="NA",aff_percentage_contempt!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='contempt',neu_percentage_contempt,aff_percentage_contempt,con_percentage_contempt)

#initiate variables for repeated measures anova
contempt<-contempt_contexts$contempt 
contempt_contexts$ID<-as.factor(contempt_contexts$ID)
contempt_contexts$context<-as.factor(contempt_contexts$context)


#get summary stats by context
sum<- contempt_contexts %>%
  group_by(context) %>%
  summarise(mean_contempt=mean(contempt, na.rm=TRUE), sd_contempt=sd(contempt, na.rm=TRUE))
sum

#now do ANOVA
contempt_anova<-aov(contempt~context+Error(ID/context),contempt_contexts)
summary(contempt_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = contempt_contexts, dv = contempt, wid = ID,
  within = context)
res.aov 



######disgust----
#Convert data from wide to long format
disgust_contexts<- df%>%
  select(ID,neu_percentage_disgust,con_percentage_disgust,aff_percentage_disgust)%>%
  filter(neu_percentage_disgust!="NA",con_percentage_disgust!="NA",aff_percentage_disgust!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='disgust',neu_percentage_disgust,aff_percentage_disgust,con_percentage_disgust)

#initiate variables for repeated measures anova
disgust<-disgust_contexts$disgust 
disgust_contexts$ID<-as.factor(disgust_contexts$ID)
disgust_contexts$context<-as.factor(disgust_contexts$context)


#get summary stats by context
sum<- disgust_contexts %>%
  group_by(context) %>%
  summarise(mean_disgust=mean(disgust, na.rm=TRUE), sd_disgust=sd(disgust, na.rm=TRUE))
sum

#now do ANOVA
disgust_anova<-aov(disgust~context+Error(ID/context),disgust_contexts)
summary(disgust_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = disgust_contexts, dv = disgust, wid = ID,
  within = context)
res.aov 



######fear----
#Convert data from wide to long format
fear_contexts<- df%>%
  select(ID,neu_percentage_fear,con_percentage_fear,aff_percentage_fear)%>%
  filter(neu_percentage_fear!="NA",con_percentage_fear!="NA",aff_percentage_fear!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='fear',neu_percentage_fear,aff_percentage_fear,con_percentage_fear)

#initiate variables for repeated measures anova
fear<-fear_contexts$fear 
fear_contexts$ID<-as.factor(fear_contexts$ID)
fear_contexts$context<-as.factor(fear_contexts$context)


#get summary stats by context
sum<- fear_contexts %>%
  group_by(context) %>%
  summarise(mean_fear=mean(fear, na.rm=TRUE), sd_fear=sd(fear, na.rm=TRUE))
sum

#now do ANOVA
fear_anova<-aov(fear~context+Error(ID/context),fear_contexts)
summary(fear_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = fear_contexts, dv = fear, wid = ID,
  within = context)
res.aov 




######sadness----
#Convert data from wide to long format
sadness_contexts<- df%>%
  select(ID,neu_percentage_sadness,con_percentage_sadness,aff_percentage_sadness)%>%
  filter(neu_percentage_sadness!="NA",con_percentage_sadness!="NA",aff_percentage_sadness!="NA")%>%#dropping these as have missing data which causes error in anova
  gather(key='context',value='sadness',neu_percentage_sadness,aff_percentage_sadness,con_percentage_sadness)

#initiate variables for repeated measures anova
sadness<-sadness_contexts$sadness 
sadness_contexts$ID<-as.factor(sadness_contexts$ID)
sadness_contexts$context<-as.factor(sadness_contexts$context)


#get summary stats by context
sum<- sadness_contexts %>%
  group_by(context) %>%
  summarise(mean_sadness=mean(sadness, na.rm=TRUE), sd_sadness=sd(sadness, na.rm=TRUE))
sum

#now do ANOVA
sadness_anova<-aov(sadness~context+Error(ID/context),sadness_contexts)
summary(sadness_anova) #


#Using anova_test to get Mauchley's test of sphericity
res.aov <- anova_test(
  data = sadness_contexts, dv = sadness, wid = ID,
  within = context)
res.aov 




#correlations between facial measures----


cor.test(df$expressivity_score,df$inhibition_score)
cor.test(df$expressivity_score,df$production_score)
cor.test(df$expressivity_score,df$competence_score)
cor.test(df$expressivity_score,df$readability)
cor.test(df$expressivity_score,df$p_readability)
cor.test(df$inhibition_score,df$production_score)
cor.test(df$inhibition_score,df$competence_score)
cor.test(df$inhibition_score,df$readability)
cor.test(df$inhibition_score,df$p_readability)
cor.test(df$production_score,df$competence_score)
cor.test(df$production_score,df$readability)
cor.test(df$production_score,df$p_readability)
cor.test(df$competence_score,df$readability)
cor.test(df$competence_score,df$p_readability)
cor.test(df$readability,df$p_readability)












#personality and expressivity----

cor.test(df$expressivity_score,df$Extraversion)
cor.test(df$expressivity_score,df$Agreeableness)
cor.test(df$expressivity_score,df$Openness)
cor.test(df$expressivity_score,df$Emotional_Stability)
cor.test(df$expressivity_score,df$Extraversion)


#liking ratings ----

#facial measures and like scores
cor.test(df$like_score_confederate,df$expressivity_score)
cor.test(df$like_score_confederate,df$inhibition_score)
cor.test(df$like_score_confederate,df$production_score)
cor.test(df$like_score_confederate,df$competence_score)
cor.test(df$like_score_confederate,df$readability)
cor.test(df$like_score_confederate,df$p_readability)

cor.test(df$like_score_raters,df$expressivity_score)
cor.test(df$like_score_raters,df$inhibition_score)
cor.test(df$like_score_raters,df$production_score)
cor.test(df$like_score_raters,df$competence_score)
cor.test(df$like_score_raters,df$readability)
cor.test(df$like_score_raters,df$p_readability)



#personality and like scores
cor.test(df$like_score_confederate,df$Extraversion)
cor.test(df$like_score_confederate,df$Agreeableness)
cor.test(df$like_score_confederate,df$Openness)
cor.test(df$like_score_confederate,df$Emotional_Stability)
cor.test(df$like_score_confederate,df$Extraversion)

cor.test(df$like_score_raters,df$Extraversion)
cor.test(df$like_score_raters,df$Agreeableness)
cor.test(df$like_score_raters,df$Openness)
cor.test(df$like_score_raters,df$Emotional_Stability)
cor.test(df$like_score_raters,df$Extraversion)



#reward outcome ----

glm1<-glm(reward~Agreeableness+con_expressivity_score+Agreeableness*con_expressivity_score, data=df, family=binomial)
summary(glm1) 
